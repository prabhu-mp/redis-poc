from sentence_transformers import SentenceTransformer
from redis.commands.search.query import Query
from redis.commands.search.field import TextField, TagField, VectorField
from redis.commands.search.indexDefinition import IndexDefinition, IndexType

import numpy as np
import redis

model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

r = redis.Redis(decode_responses=True)

# try:
#     r.ft("vector_idx").dropindex(True)
# except redis.exceptions.ResponseError:
#     pass
#
#
# schema = (
#     TextField("content"),
#     TagField("genre"),
#     VectorField("embedding", "HNSW", {
#         "TYPE": "FLOAT32",
#         "DIM": 384,
#         "DISTANCE_METRIC":"L2"
#     })
# )
#
# r.ft("vector_idx").create_index(
#     schema,
#     definition=IndexDefinition(
#         prefix=["doc:"], index_type=IndexType.HASH
#     )
# )
#
content = "That is a very happy person"
print(model.encode(content).astype(np.float32))
#
# r.hset("doc:0", mapping={
#     "content": content,
#     "genre": "persons",
#     "embedding": model.encode(content).astype(np.float32).tobytes(),
# })
#
content = "That is a happy dog"
print(model.encode(content).astype(np.float32))
#
# r.hset("doc:1", mapping={
#     "content": content,
#     "genre": "pets",
#     "embedding": model.encode(content).astype(np.float32).tobytes(),
# })
#
content = "Today is a sunny day"
print(model.encode(content).astype(np.float32))
#
# r.hset("doc:2", mapping={
#     "content": content,
#     "genre": "weather",
#     "embedding": model.encode(content).astype(np.float32).tobytes(),
# })

q = Query(
    "*=>[KNN 3  @embedding $vec AS vector_distance]"
).return_fields("score", "id", "content").dialect(2)

query_text = "That is a happy person"

print(model.encode(query_text).astype(np.float32))

res = r.ft("vector_idx").search(
    q, query_params={
        "vec": model.encode(query_text).astype(np.float32).tobytes()
    }
)

print(res)